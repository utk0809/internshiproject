<?php
$uploadMessage = '';
$messageClass = '';
$uploadedFileName = '';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $targetDir = "uploads/";
    
    // Ensure the uploads directory exists
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    // Check if a file was selected
    if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] === UPLOAD_ERR_OK) {
        $fileName = basename($_FILES["fileToUpload"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        
        // TASK A: INSECURE UPLOAD (Allows ANY file type)
        // No validation checks are performed here.
        
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
            $uploadMessage = "File uploaded successfully! (Insecure)";
            $messageClass = "success";
            $uploadedFileName = htmlspecialchars($fileName);
        } else {
            $uploadMessage = "There was an error moving the uploaded file.";
            $messageClass = "error";
        }
    } else {
        $uploadMessage = "Please select a valid file to upload.";
        $messageClass = "error";
        
        // Handle specific upload errors
        if(isset($_FILES['fileToUpload'])) {
            switch ($_FILES['fileToUpload']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    $uploadMessage = "File is too large.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $uploadMessage = "File was only partially uploaded.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $uploadMessage = "No file was uploaded.";
                    break;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload Vulnerability - Part A</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <div class="nav-tabs">
        <a href="index.php" class="nav-tab active">Part A: Insecure</a>
        <a href="secure.php" class="nav-tab">Part B: Secure</a>
    </div>

    <div class="header">
        <h1>Insecure File Upload</h1>
        <p class="subtitle">Part A: Vulnerability Simulation</p>
    </div>

    <div class="card">
        <div class="educational-panel">
            <h3>📝 Educational Context</h3>
            <p>This section demonstrates an <strong>insecure</strong> file upload process. It performs exactly zero validation on the uploaded file type, extension, or content. This means a malicious user could potentially upload executable code (like a PHP web shell) and compromise the server.</p>
        </div>

        <form action="index.php" method="POST" enctype="multipart/form-data" class="upload-form">
            <div class="file-input-wrapper">
                <input type="file" name="fileToUpload" id="fileToUpload" class="file-input">
            </div>
            <button type="submit" name="submit" class="upload-btn">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 4V16M12 4L8 8M12 4L16 8M4 20H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Upload Any File
            </button>
        </form>

        <?php if (!empty($uploadMessage)): ?>
            <div class="message <?php echo $messageClass; ?>">
                <?php echo $uploadMessage; ?>
                <?php if (!empty($uploadedFileName)): ?>
                    <div class="uploaded-filename">
                        <strong>Uploaded File:</strong> <?php echo $uploadedFileName; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
